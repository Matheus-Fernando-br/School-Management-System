package com.sge.util;

public class Notas {
}
