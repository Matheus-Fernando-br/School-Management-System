package com.sge.util;

public class Utilitarios {
}
