package com.sge.main;
import com.sge.telas.LoginFrame;

public class Main {
    public static void main(String[] args) {
        new LoginFrame().setVisible(true);
    }
}
