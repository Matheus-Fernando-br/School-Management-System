package com.sge.telas;

import javax.swing.*;

public class ConsultarCursoFrame extends JFrame {
}
